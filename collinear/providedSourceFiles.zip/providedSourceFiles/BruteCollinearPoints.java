/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {

    private ArrayList<LineSegment> lineSegments;
    private int lineSegmentCount;

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        if (points == null) {
            throw new java.lang.IllegalArgumentException("Cannot input array equal to 'null'.");
        }

        Point[] sortedPoints = new Point[points.length];
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) {
                throw new java.lang.IllegalArgumentException("Cannot input array equal to 'null'.");
            }
            for (int j = 0; j < points.length; j++) {
                if (i != j && points[i].equals(points[j])) {
                    throw new java.lang.IllegalArgumentException("Repeated point found");
                }
            }
            sortedPoints[i] = points[i];
        }
        Arrays.sort(sortedPoints);
        lineSegments = new ArrayList<LineSegment>();
        lineSegmentCount = 0;

        ArrayList<Point> firstPoints = new ArrayList<Point>();
        ArrayList<Point> finalPoints = new ArrayList<Point>();
        boolean duplicateFlag = false;
        for (int i = 0; i < sortedPoints.length - 3; i++) {
            for (int j = i + 1; j < sortedPoints.length - 2; j++) {
                for (int k = j + 1; k < sortedPoints.length - 1; k++) {
                    if (sortedPoints[i].slopeTo(sortedPoints[j]) == sortedPoints[j]
                            .slopeTo(sortedPoints[k])) {
                        for (int m = k + 1; m < sortedPoints.length; m++) {
                            if (sortedPoints[i].slopeTo(sortedPoints[j]) == sortedPoints[k]
                                    .slopeTo(sortedPoints[m])) {
                                if (sortedPoints[i].compareTo(sortedPoints[j]) < 0
                                        && sortedPoints[j].compareTo(sortedPoints[k]) < 0
                                        && sortedPoints[k].compareTo(sortedPoints[m]) < 0) {
                                    for (Point p : firstPoints) {
                                        for (Point q : finalPoints) {
                                            if (p.slopeTo(q) == sortedPoints[i]
                                                    .slopeTo(sortedPoints[j])
                                                    && sortedPoints[i].compareTo(p) >= 0
                                                    && sortedPoints[m].compareTo(q) <= 0
                                            ) {
                                                duplicateFlag = true;
                                            }
                                        }
                                    }
                                    if (!duplicateFlag) {
                                        firstPoints.add(sortedPoints[i]);
                                        finalPoints.add(sortedPoints[m]);
                                        lineSegments
                                                .add(new LineSegment(sortedPoints[i],
                                                                     sortedPoints[m]));
                                        lineSegmentCount++;
                                    }
                                    duplicateFlag = false;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // the number of line segments
    public int numberOfSegments() {
        return lineSegmentCount;
    }

    // the line segments
    public LineSegment[] segments() {
        LineSegment[] segmentArray = new LineSegment[lineSegmentCount];
        for (int i = 0; i < lineSegmentCount; i++) {
            segmentArray[i] = lineSegments.get(i);
        }
        return segmentArray;
    }

    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();


        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);

        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();

    }
}
